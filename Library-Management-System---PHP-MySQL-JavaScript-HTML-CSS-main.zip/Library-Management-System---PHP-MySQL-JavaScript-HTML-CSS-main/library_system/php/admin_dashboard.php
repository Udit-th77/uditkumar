if ($_SESSION['role'] === 'admin') {
    echo "<a href='admin_dashboard.php'>Admin Dashboard</a>";
}
